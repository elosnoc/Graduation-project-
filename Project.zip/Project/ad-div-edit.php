<?php include 'ac-checklogin.php';?>
<!DOCTYPE html>
<html>
  <head>
    <title>ค้นหางานวิจัย | ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	
	?>
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'ad-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">
		
<?php 
					   	
   
				$strKeyword = null;
				if(isset($_POST["fac"]))
				{
					$strKeyword = $_POST["fac"];
				}
			
			include'action/dblink.php';
			$sql2 = "SELECT *
					 FROM faculty";
			$query2= mysqli_query($link, $sql2);	
			
			$sql = "SELECT * 	
					FROM division
					WHERE fac_id LIKE '%".$strKeyword."%'";		
			$query= mysqli_query($link, $sql);	

		
?>


			 <div class="container-fluid">
              <div class="row">                
                <div class="col-lg-10 mx-auto">
                  <div class="daily-feeds card">                     
                    <div class="card-header">
                      <h3 class="h4">แก้ไขสาขาวิชา</h3>
                    </div>
                    <div class="card-body no-padding">
                      <!-- Item-->
                      <div class="item">
                        <div class="feed d-flex justify-content-between">                       
						  <div class="table-responsive"> 
								<form name="frmSearch" method="post" action="<?php echo $_SERVER['SCRIPT_NAME'];?>">
								<div class="input-group col-lg-10 mb-3 center_div">					
									
									
									<select id="fac" name="fac" class="custom-select">
										<option  value="" disabled selected>-- กรุณาเลือก --</option>
										<?php 
										while($objResult2 = mysqli_fetch_array($query2)){
										?>								
										<option value="<?php echo $objResult2["fac_id"]; ?>"  <?php if($objResult2["fac_id"] == $strKeyword) {echo 'selected';}?>>   <?php echo $objResult2["mem_fac"];?> </option>																	
										<?php																				
										}
										$strKeyword = $objResult2["fac_id"];
										?>								
									</select>	
									<div class="input-group-append">
										<input type="submit" class="btn btn-primary" type="submit" value="Search"></button>
									</div>
								</div>
							</form>
							<table class="table ">							
							  <tbody>							
								<tr style="text-align:center;">
								  <th scope="col"></th>
								  <th scope="col"></th>								  
								  <th scope="col"><a class="btn btn-info offset-lg-5" href="ad-divadd.php">เพิ่มสาขาวิชา</a></th>
								</tr>
							  </tbody> 
							</table>
							
							<table class="table table-striped table-hover">							
								
							  <thead>
								<tr style="text-align:center;">
								  <th scope="col">#</th>
								  <th scope="col">ชื่อสาขาวิชา</th>								  
								  <th scope="col"></th>
								</tr>
							  </thead>
							  
							  <tbody>					
								  
									  <?php 								
											$count = 1;
											while($row = mysqli_fetch_array($query)) {
											echo "<tr>";
											echo"<th class\"row\"><center> $count </center></th>";
											$count++;																					
											echo "<td><center>".$row["div_name"]." </center></td>";											
											echo "<td> 													
													<center><a href=\"action/ac-divdel.php?id=$row[div_id]\" class=\"btn btn-danger\" onclick=\"return confirm('กรุณายืนยันการลบอีกครั้ง !!!')\">ลบสาขาวิชา</a>
													<a href=\"ad-div-edit-form.php?id=$row[div_id]\" class=\"btn btn-warning\">แก้ไขสาขาวิชา</a></center>
												</td>";
										
											echo"</tr>";
										}							
										?>		
							  </tbody>
							</table>
							
						  </div>
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
  </body>
</html>