<?php include 'ac-checklogin.php';?>
<!DOCTYPE html>
<html>
  <head>
    <title>ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	?>
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'a-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">

            <div class="container-fluid">
              <div class="row">                
				<div class="col-lg-10 mx-auto">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">ส่งงานวิจัย</h3>
                    </div>
                    <div class="card-body">
                      <p>กรุณากรอกรายละเอียดงานวิจัยให้ครบถ้วน</p>
					  
                      <form class="form-horizontal" action="ac-resend.php" method="post" enctype="multipart/form-data">					  
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">ชื่องานวิจัยภาษาไทย</label>
                          <div class="col-sm-9">
                            <input name="name-th" type="text"  class="form-control form-control-success" required>
							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-3 form-control-label">ชื่องานวิจัยภาษาอังกฤษ</label>
                          <div class="col-sm-9">
                            <input name="name-eng" type="text"  class="form-control form-control-success" required>
							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-3 form-control-label">ประเภทของงานวิจัย</label>
                          <div class="col-sm-9">
                            <input name="re-type" type="text" class="form-control form-control-success" required>
							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-3 form-control-label">ประเภทงบประมาณ</label>
                          <div class="col-sm-9">
                             <select name="money"  class="custom-select" required>
								<option value="">เลือกประเภทงบประมาณ</option>								
								<option value="งบประมาณแผ่นดิน">งบประมาณแผ่นดิน</option>
								<option value="งบประมาณภายนอก">งบประมาณภายนอก</option>								
							  </select>
							  
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-3 form-control-label">ปีที่วิจัยเสร็จสิ้น</label>
                          <div class="col-sm-9">
                             <select name="year"  class="custom-select" required>
								<option value="">เลือกปีที่วิจัยเสร็จสิ้น</option>
								<?php
								$cur_year = intval(date('Y'))+543;
								for($year =$cur_year ; $year>= 2550; $year--)
								{
									echo "<option value=\"$year\">$year</option>";
								}
								?>
							  </select>							
                          </div>
                        </div>
						<hr>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">อัพโหลดไฟล์</label>
                          <div class="col-sm-9">
                            <input type="file" accept="application/pdf" name="my_file" required>
							<small class="form-text">กรุณาเลือกไฟล์ pdf เท่านั้น</small>
                          </div>
                        </div>
						<hr>
                        <div class="form-group row">       
                          <div class="col-sm-9 offset-sm-3">
                            <input type="submit" value="บันทึกข้อมูลงานวิจัย" class="btn btn-primary">
                          </div>
                        </div>
						
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			



          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
  </body>
</html>