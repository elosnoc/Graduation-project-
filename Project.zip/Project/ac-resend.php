<?php
include 'ac-checklogin.php';
$link = mysqli_connect('localhost', 'root', '', 'research') or die(mysqli_connect_error());
mysqli_set_charset($link, "utf8");				

if (($_FILES['my_file']['name']!="" && $_FILES["my_file"]["type"] == "application/pdf")){
// Where the file is going to be stored
	$target_dir = "uploads/";
	$file = $_FILES['my_file']['name'];
	$path = pathinfo($file);
	$filename = $path['filename'];
	$ext = $path['extension'];
	$temp_name = $_FILES['my_file']['tmp_name'];
	$path_filename_ext = $target_dir.$filename.".".$ext;
 
// Check if file already exists
 move_uploaded_file($temp_name,$path_filename_ext);
	



$sql= "	INSERT INTO attribute (re_name_th,re_name_eng,re_year,re_type,re_money,username,re_abs) 
		VALUES (
				'".$_POST["name-th"]."',
				'".$_POST["name-eng"]."',
				'".$_POST["year"]."',
				'".$_POST["re-type"]."',
				'".$_POST["money"]."',
				'".$_SESSION["username"]."',
				'$path_filename_ext')";
$query = mysqli_query($link,$sql); 

	echo '<script type="text/javascript">'; 
	echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
	echo 'window.location.href = "index.php";';
	echo '</script>';
}
else
{
	echo '<script type="text/javascript">'; 
	echo 'alert("กรุณาเลือกไฟล์  PDF เท่านั้น !!!");'; 
	echo 'window.location.href = "resend.php";';
	echo '</script>';
}	

mysqli_close($link);
?>

