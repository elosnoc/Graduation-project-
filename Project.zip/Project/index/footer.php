 <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>มหาวิทยาลัยเทคโนโลยีราชมงคลอีสานวิทยาเขตขอนแก่น</h3>
                        </div>
                        <p> 
							150 ถ.ศรีจันทร์ ต.ในเมือง
							อ.เมือง จ.ขอนแก่น 40000
							โทรศัพท์ 043-283700 (ระบบอัตโนมัติ)
						</p>   
						<div class="footer-right">
							<ul class="footer-links-soi">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-github"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul><!-- end links -->
						</div>						
                    </div><!-- end clearfix -->
                </div><!-- end col -->

				<div class="col-lg-4 col-md-4 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>มทร.อีสาน</h3>
                        </div>
                        <ul class="footer-links">
                            <li><a href="#">มทร.อีสาน วิทยาเขตสุรินทร์</a></li>
                            <li><a href="#">มทร.อีสาน วิทยาเขตสกลนคร</a></li>
                            <li><a href="#">มทร.อีสาน นครราชสีมา</a></li>
							<li><a href="#">มทร.อีสาน วิทยาเขตร้อยเอ็ด ณ ทุ่งกุลาร้องไห้</a></li>							
                        </ul><!-- end links -->
                    </div><!-- end clearfix -->
                </div><!-- end col -->
				
                <div class="col-lg-4 col-md-4 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>ส่วนงานที่เกี่ยวข้องอื่นๆ</h3>
                        </div>

                        <ul class="footer-links">                            
                            <li><a href="http://apps.kkc.rmuti.ac.th/stdaff/">ระบบกิจกรรม มทร.อีสาน ขอนแก่น</a></li>
                            <li><a href="https://khonkaen-ess.rmuti.ac.th/">Ess RMUTI KKC</a></li>                            
                        </ul><!-- end links -->
                    </div><!-- end clearfix -->
                </div><!-- end col -->
				
            </div><!-- end row -->
        </div><!-- end container -->
    </footer><!-- end footer -->

    <div class="copyrights">
        <div class="container">
            <div class="footer-distributed">
                <div class="footer-center">                   
                    <p class="footer-company-name">All Rights Reserved. &copy; 2018 <a href="#">RESEARCH DATABASE</a> Design By : <a href="https://www.kkc.rmuti.ac.th/2017/">RMUTI KKC</a></p>
                </div>
            </div>
        </div><!-- end container -->
    </div><!-- end copyrights -->