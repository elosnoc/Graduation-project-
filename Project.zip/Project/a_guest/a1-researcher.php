<!DOCTYPE html>
<html>
  <head>
    <title>ค้นหางานวิจัย | ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a1-top.php';
	?>
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a1-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'a1-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">
		  
		
<?php	
   
				$strKeyword = null;
				if(isset($_POST["research"]))
				{
					$strKeyword = $_POST["research"];
				}

			include'../action/dblink.php';
			$sql = "SELECT *  FROM member
					LEFT JOIN division 
					ON member.div_id = division.div_id
					LEFT JOIN faculty
					ON member.fac_id = faculty.fac_id
					WHERE  member.mem_name 
					LIKE '%".$strKeyword."%'
					OR member.mem_surname
					LIKE '%".$strKeyword."%'";					
			$query= mysqli_query($link, $sql);
			
?>
			 <div class="container-fluid">
              <div class="row">                
                <div class="col-lg-12">
                  <div class="daily-feeds card">                     
                    <div class="card-header">
                      <h3 class="h4">ค้นหาชื่อผู้วิจัยจากชื่อ-นามสกุล</h3>
                    </div>					
						<center><br>
							<form name="frmSearch" method="post" action="<?php echo $_SERVER['SCRIPT_NAME'];?>">
								<div class="input-group col-lg-9 mb-3 center_div">
									<input type="text" name="research" class="form-control" id="research" placeholder="พิมพ์ชื่องานวิจัยที่ท่านต้องการค้นหา" value="<?php echo $strKeyword;?>" >
									<div class="input-group-append">
										<button class="btn btn-primary" type="submit" value="Search">ค้นหา</button>
									</div>
								</div>
							</form>
						</center>
                  </div>
                </div>
              </div>
            </div>

			 <div class="container-fluid">
              <div class="row">                
                <div class="col-lg-12">
                  <div class="daily-feeds card">                     
                    <div class="card-header">
                      <h3 class="h4">รายชื่อนักวิจัย</h3>
                    </div>
                    <div class="card-body no-padding">
                      <!-- Item-->
                      <div class="item">
                        <div class="feed d-flex justify-content-between">                       
						  <div class="table-responsive" style="overflow:scroll; overflow-x: scroll; overflow-y:hidden;">                       
							<table class="table table-striped table-hover" style="width:70em; margin:auto;" >
							  <thead>
								<tr>
								  <th>#</th>
								  <th>ชื่อนักวิจัย</th>
								  <th>คณะ</th>
								  <th>สาขาวิชา</th>
								</tr>
							  </thead>
							  <tbody>
							<?php 								
								$count = 1;
								while($row = mysqli_fetch_array($query)) {
								if($row["status"]=="admin")
									{
										
									}
								else{
								echo "<tr>";
								echo"<th class\"row\"> $count </th>";
								$count++;
								echo "<td> ".$row['mem_name']."  ".$row['mem_surname']." </td>";								
								echo "<td> {$row['mem_fac']}</td>";
								echo "<td> {$row['div_name']}</td>";								
								echo"</tr>";
								}
							}							
							?>									
							  </tbody>
							</table>
						  </div>
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/popper.js/umd/popper.min.js"> </script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <script src="../vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="../js/charts-home.js"></script>
    <!-- Main File-->
    <script src="../js/front.js"></script>
  </body>
</html>