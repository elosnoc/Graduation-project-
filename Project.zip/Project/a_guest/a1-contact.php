<!DOCTYPE html>
<html>
  <head>
    <title>ค้นหางานวิจัย | ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a1-top.php';
	?>
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a1-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'a1-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">
			 <div class="container-fluid">
              <div class="row">                
                <div class="col-lg-12">
                  <div class="daily-feeds card">                     
                   <div class="card-body">              
					  <h4>ติดต่อเรา</h4> 
					  <br>
					   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3826.932356452091!2d102.86140831438414!3d16.428261488659942!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31228bda829566e7%3A0x24ca9da06e436ef3!2z4Lih4Lir4Liy4Lin4Li04LiX4Lii4Liy4Lil4Lix4Lii4LmA4LiX4LiE4LmC4LiZ4LmC4Lil4Lii4Li14Lij4Liy4LiK4Lih4LiH4LiE4Lil4Lit4Li14Liq4Liy4LiZIOC4p-C4tOC4l-C4ouC4suC5gOC4guC4leC4guC4reC4meC5geC4geC5iOC4mQ!5e0!3m2!1sth!2sth!4v1531982270086" 
					   width="100%" height="400px" frameborder="0" style="border:0" allowfullscreen></iframe>
						<br>    	
						<h4> แผนที่ตั้งมหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยเขตขอนแก่น </h4><br>
						<p>	เวลาทำการ : จันทร์ – ศุกร์ 08.30-16.30 น. (เว้นวันหยุดราชการ)<br>
							ติดต่อ :        ฝ่ายวิจัยมหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขตขอนแก่น<br> 
									150 ถ.ศรีจันทร์ ต.ในเมือง อ.เมือง จ.ขอนแก่น 40000 <br>
						โทรศัพท์  :    043-283700-23 <br>
						โทรสาร   :    043-237483 </p>    
					</div>
				   
                  </div>
                </div>
              </div>
            </div>
          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/popper.js/umd/popper.min.js"> </script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <script src="../vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="../js/charts-home.js"></script>
    <!-- Main File-->
    <script src="../js/front.js"></script>
  </body>
</html>