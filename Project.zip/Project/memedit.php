<?php include 'ac-checklogin.php';?>
<!DOCTYPE html>
<html>
  <head>	
    <title>ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet">
    <?php	include 'a-top.php';?>
  </head>
  <body>
    <?php 
			include'action/dblink.php';
			$sql2  =  "SELECT * FROM faculty";			
			$sql   = "SELECT * FROM member WHERE member.username= '".$_SESSION['username']."' ";										
			$query = mysqli_query($link, $sql);
			$query2 = mysqli_query($link, $sql2);			
			$objResult = mysqli_fetch_array($query);						
	if(!$objResult)
	{
		echo "Not found RE =".$_SESSION["mem_id"];
	}
	else
	{	
				
	?>
  

    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'a-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">

            <div class="container-fluid">
              <div class="row">                
				<div class="col-lg-8 mx-auto">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">แก้ไขข้อมูลส่วนตัว</h3>
                    </div>					
					
                    <div class="card-body">
                      <p>กรุณากรอกรายละเอียดงานวิจัยให้ครบถ้วน</p>
                      <form class="form-horizontal" action="action/ac-memedit.php" method="get" name="form1">
						<div class="form-group row">
                          <label class="col-sm-2 form-control-label">ชื่อ</label>
                          <div class="col-sm-9">
                            <input  type="text" value="<?php echo $objResult["mem_name"] ?>" class="form-control form-control-success" name="name" required>							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-2 form-control-label">นามสกุล</label>
                          <div class="col-sm-9">
                            <input id="inputHorizontalSuccess" type="text" value="<?php echo $objResult["mem_surname"] ?>" class="form-control form-control-success" name="surname" required>							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-2 form-control-label">Email</label>
                          <div class="col-sm-9">
                            <input name="email" type="email" value="<?php echo $objResult["mem_mail"] ?>" class="form-control form-control-success" name="birth" required>							
                          </div>
                        </div>						
						
						<div class="form-group row">
                          <label class="col-sm-2 form-control-label">วัน / เดือน / ปีเกิด</label>
                          <div class="col-sm-9">
                            <input id="inputHorizontalSuccess" type="date" value="<?php echo $objResult["mem_birth"] ?>" class="form-control form-control-success" name="birth" required>							
                          </div>
                        </div>
						
						<div class="form-group row" >
                          <label class="col-sm-2 form-control-label">คณะ</label>
                          <div class="col-sm-9">
                            <select id="fac" name="faculty" class="custom-select" required>
								<option  value="" disabled selected>-- กรุณาเลือก --</option>
								<?php 
								while($objResult2 = mysqli_fetch_array($query2)){
								?>								
								<option value="<?php echo $objResult2["fac_id"]; ?>" <?php if($objResult2["fac_id"]==$objResult["fac_id"]) {echo 'selected'; $sakha=$objResult["fac_id"];} ?>> <?php echo $objResult2["mem_fac"];?> </option>																	
								<?php
								}
								?>
								
							  </select>					
                          </div>
                        </div>					
						
						<script>							
						$(document).ready(function () {
							
								
								
							$("#fac").change(function () {
								
								var val = $(this).val();								
								if (val == "1") {
																	
									$("option#sakha1").show();
									$("option#sakha2").hide();
									$("option#sakha3").hide();									
								} else if (val == "2") {
									
									$("option#sakha1").hide();
									$("option#sakha2").show();
									$("option#sakha3").hide();
								} else if (val == "3") {
									$("option#sakha1").hide();
									$("option#sakha2").hide();
									$("option#sakha3").show();
								}
								else
								{
								$("option#sakha1").hide();
								$("option#sakha2").hide();
								$("option#sakha3").hide();
								}
								
								
							});
						});		
						
						</script>
							
						<div class="form-group row">
                          <label class="col-sm-2 form-control-label">สาขาวิชา</label>
                          <div class="col-sm-9">
                             <select id="sakha" name="sakha" class="custom-select"  required>								
								<option value="" disabled selected>-- กรุณาเลือก --</option>
								<?php 
									
									$sel = " ";
									
									$sakha_chk = "SELECT * FROM member INNER JOIN division ON member.div_id = division.div_id	WHERE username = ".$_SESSION['username']." ";				
									$qsakha_chk = mysqli_query($link,$sakha_chk);
									$result = mysqli_fetch_array($qsakha_chk);
									
									$sakha1 = "SELECT * FROM division";
									$qsakha = mysqli_query($link,$sakha1);
									
									
									while($row = mysqli_fetch_array($qsakha))
									{
										if($result['div_id'] == $row['div_id'])
											$sel = "selected";
										else
											$sel = " ";
										
										if($row['fac_id']==1)										
											echo	"<option id=\"sakha1\" value=\" ".$row['div_id']. "\" ".$sel."> ".$row['div_name']."  </option>";										
										else if(($row['fac_id']==2))
											echo	"<option id=\"sakha2\" value=\" ".$row['div_id']. "\" ".$sel."> ".$row['div_name']."  </option>";
										else
											echo	"<option id=\"sakha3\" value=\" ".$row['div_id']. "\" ".$sel."> ".$row['div_name']."  </option>";										
																									
								
									}
								?>
				
							  </select>					
                          </div>
                        </div>
						

						
						<hr>
                        <div class="form-group row">       
                          <div class="col-sm-9 offset-sm-3">
                            <input type="submit" value="บันทึกข้อมูล" class="btn btn-primary">
                          </div>
                        </div>
						
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
	
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>   
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
	<script src="js/script.js"></script>

	
    <!-- Main File-->
    <script src="js/front.js"></script>
	<?php
	}
	?>
  </body>
</html>