$(document).ready(function(){
  $('#citizen').mask('0-0000-00000-00-0');
  $('#phone-number').mask('0000-0000');
 })