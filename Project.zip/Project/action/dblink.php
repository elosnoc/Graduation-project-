<?php
$link = @mysqli_connect('localhost', 'root', '', 'research') or die(mysqli_connect_error());
mysqli_set_charset($link, "utf8");

?>
