<?php
include 'ac-checklogin.php';
	$serverName = "localhost";
	$userName = "root";
	$userPassword = "";
	$dbName = "research";

	$objCon = mysqli_connect($serverName,$userName,$userPassword,$dbName);

	$strSQL = "	Update member 
				SET password = '".$_POST['confpass']."' 
				WHERE username = '".$_SESSION['username']."' ";
	
	$sql = "SELECT password 
			FROM member 
			WHERE username = '".$_SESSION['username']."' ";
	
	$objQuery = mysqli_query($objCon,$sql);
	$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);
	
if($_SESSION['username']!="admin")
{
		
	if($_POST["newpass"]!= $_POST["confpass"])
{
	echo '<script type="text/javascript">'; 
	echo 'alert("ป้อนรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง");';
	echo 'window.location = "../chgpass.php";'; 	
	echo '</script>';
}
	

else
{
	if($objResult["password"] != $_POST["oldpass"])
	{
		echo '<script type="text/javascript">'; 
		echo 'alert("ป้อนรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง");';
		echo 'window.location = "../chgpass.php";';
		echo '</script>';
	}
	else
	{
		if ($objCon->query($strSQL) === TRUE)
		{
			echo '<script type="text/javascript">'; 
			echo 'alert("บันทึกข้อมูลเรียบร้อยแล้ว");';
			echo 'window.location = "../index.php";';
			echo '</script>';
		}
		else
		{
			echo "ERROR " . $objCon->error;
		}	
	}
}
	
	
}
else
{
	
if($_POST["newpass"]!= $_POST["confpass"])
{
	echo '<script type="text/javascript">'; 
	echo 'alert("ป้อนรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง");';
	echo 'window.location = "../ad-chgpass.php";'; 	
	echo '</script>';
}
	

else
{
	if($objResult["password"] != $_POST["oldpass"])
	{
		echo '<script type="text/javascript">'; 
		echo 'alert("ป้อนรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง");';
		echo 'window.location = "../ad-chgpass.php";';
		echo '</script>';
	}
	else
	{
		if ($objCon->query($strSQL) === TRUE)
		{
			echo '<script type="text/javascript">'; 
			echo 'alert("บันทึกข้อมูลเรียบร้อยแล้ว");';
			echo 'window.location = "../index.php";';
			echo '</script>';
		}
		else
		{
			echo "ERROR " . $objCon->error;
		}	
	}
}
}
	?>