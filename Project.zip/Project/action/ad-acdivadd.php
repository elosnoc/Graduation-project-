<?php
$link = mysqli_connect('localhost', 'root', '', 'research') or die(mysqli_connect_error());
mysqli_set_charset($link, "utf8");
$sql= " INSERT INTO `division` (`div_id`, `div_name`, `fac_id`) 
		VALUES (NULL, '".$_POST["div"]."', '".$_POST["fac"]."')";
				
$query = mysqli_query($link,$sql);

if($query)
{
	echo '<script type="text/javascript">'; 
	echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
	echo 'window.location.href = "../ad-div-edit.php";';
	echo '</script>';
}

?>