<?php
$link = mysqli_connect('localhost', 'root', '', 'research') or die(mysqli_connect_error());
mysqli_set_charset($link, "utf8");
$sql= " INSERT INTO `member` (`username`, `password`, `status`, `mem_name`, `mem_surname`, `mem_birth`, `mem_mail`,  `fac_id`, `div_id`) 
		VALUES ('".$_POST["username"]."', '".$_POST["password"]."', 'user', '".$_POST["name"]."', '".$_POST["surname"]."', NULL, NULL, NULL, NULL)";
				
$query = mysqli_query($link,$sql);

if($query)
{
	echo '<script type="text/javascript">'; 
	echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
	echo 'window.location.href = "../ad-memedit.php";';
	echo '</script>';
}
else
{
	echo '<script type="text/javascript">'; 
	echo 'alert("ไม่สามารถเพิ่มสมาชิกได้ กรุณาลองอีกครั้ง");'; 
	echo 'window.location.href = "../ad-memedit.php";';
	echo '</script>';
}
mysqli_close($link);
?>

