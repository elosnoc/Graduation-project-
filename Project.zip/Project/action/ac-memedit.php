<?php
include 'ac-checklogin.php';
$link = mysqli_connect('localhost', 'root', '', 'research') or die(mysqli_connect_error());
mysqli_set_charset($link, "utf8");				


	mysqli_set_charset($link, "utf8");
	$sql= "	UPDATE member 
			SET 	mem_name = '".$_GET["name"]."',
					mem_surname ='".$_GET["surname"]."',					
					mem_birth ='".$_GET["birth"]."',
					fac_id ='".$_GET["faculty"]."',
					div_id ='".$_GET["sakha"]."',					
					mem_mail ='".$_GET["email"]."'
			WHERE	 username = '".$_SESSION['username']."' ";
			
			$query = mysqli_query($link,$sql); 
if($query)
{
	echo '<script type="text/javascript">'; 
	echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
	echo 'window.location.href = "../memedit.php";';
	echo '</script>';
}



	
?>

