<?php
	session_start();
	$serverName = "localhost";
	$userName = "root";
	$userPassword = "";
	$dbName = "research";

	$objCon = mysqli_connect($serverName,$userName,$userPassword,$dbName);

	$strSQL = "	SELECT * 
				FROM member 
				WHERE username = '".mysqli_real_escape_string($objCon,$_POST['username'])."' 
				AND password = '".mysqli_real_escape_string($objCon,$_POST['password'])."'";
	$objQuery = mysqli_query($objCon,$strSQL);
	$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);	
	
	mysqli_close($objCon);

  if(!$objResult)
	{
			echo '<script type="text/javascript">'; 
			echo 'alert("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง \\n กรุณาเข้าสู่ระบบอีกครั้ง");'; 
			echo 'window.location.href = "../login.php";';
			echo '</script>';
			
	}
	else
	{
			
			$_SESSION["username"] = $objResult["username"];
			$_SESSION["status"] = $objResult["status"];			
			session_write_close();			
			if($objResult["status"] == "user")
			{
				header("location:../index.php");
			}
			else
			{
				header("location:../index.php");
			}
	}  
  ?>