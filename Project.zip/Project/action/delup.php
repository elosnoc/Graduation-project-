<?php
	ini_set('display_errors', 1);
	error_reporting(~0);

	$serverName = "localhost";
	$userName = "root";
	$userPassword = "";
	$dbName = "research";

	$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

	$id = $_GET["id"];
	$sql = "UPDATE attribute 
			SET re_abs =''
			WHERE re_id = '".$id."' ";

	$query = mysqli_query($conn,$sql);

	if(mysqli_affected_rows($conn)) { ?>
					<meta http-equiv="refresh" content="0.5;URL='../reedit-form.php?id=<?php echo $id; ?>' ">	
						
			     
	<?php		
	}

	mysqli_close($conn);
?>