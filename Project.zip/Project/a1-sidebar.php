<nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            
            <div class="title">
			  <h1 class="h4">ยินดีต้อนรับ</h1>
              <h1 class="h4"></h1>
              <p>สถานะ : ผู้เยี่ยมชม</p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">เมนูหลัก</span>
          <ul class="list-unstyled">
                    <li class="active"><a href="a1-index.php"> <i class="icon-home"></i>ค้นหางานวิจัย </a></li>
                    
					<li><a href="#research" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>ค้นหางานวิจัย </a>
                      <ul id="research" class="collapse list-unstyled">
                        <li><a href="resend.php">ค้นหาจากชื่องานวิจัย</a></li>
						<li><a href="resend.php">ค้นหาจากชื่อผู้วิจัย</a></li>
						<li><a href="resend.php">ค้นหาจากปี่ที่วิจัย</a></li>
						<li><a href="resend.php">ค้นหาจากประเภทงบประมาณ</a></li>
						<li><a href="resend.php">ค้นหาจากประเภทงานวิจัย</a></li>                                              
                      </ul>
                    </li>
					
					<li><a href="#researcher" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>ค้นหานักวิจัย </a>
                      <ul id="researcher" class="collapse list-unstyled ">
                        <li><a href="resend.php">ค้นหาจากชื่อ</a></li>
						<li><a href="resend.php">ค้นหาจากชื่อคณะ</a></li>
						<li><a href="resend.php">ค้นหาจากชื่อสาขา</a></li>						                                             
                      </ul>
                    </li>
					
					
					<li><a href="a_guest/a1-researcher.php"> <i class="icon-grid"></i>รายชื่อนักวิจัย </a></li>
                    <li><a href="a_guest/a1-contact.php"> <i class="fa fa-bar-chart"></i>ติดต่อเรา </a></li>
                    
                    <li><a href="login.php"> <i class="icon-interface-windows"></i>เข้าสู่ระบบ</a></li>
          </ul>        
        </nav>