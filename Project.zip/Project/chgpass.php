<?php include 'ac-checklogin.php';?>
<!DOCTYPE html>
<html>
  <head>
    <title>ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	?>
  </head>
  <body>

  
  
  
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php
		if($_SESSION['status']=="user")
		{
			include 'a-sidebar.php';
		}
		else 
		{
			include 'ad-sidebar.php';
		}
		
		?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">

            <div class="container-fluid">
              <div class="row">                
				<div class="col-lg-5 mx-auto">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">เปลี่ยนรหัสผ่าน</h3>
                    </div>
                    <div class="card-body">
                      <p>กรุณากรอกรายละเอียดงานวิจัยให้ครบถ้วน</p>
                      <form class="form-horizontal" method="post" action="action/ac-chgpass.php">
					  
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">รหัสผ่านเดิม</label>
                          <div class="col-sm-9">
                            <input name="oldpass" type="password"  class="form-control form-control-success" required>
							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-3 form-control-label">รหัสผ่านใหม่</label>
                          <div class="col-sm-9">
                            <input name="newpass" type="password"  class="form-control form-control-success" required>
							
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-3 form-control-label">ยืนยันรหัสผ่าน</label>
                          <div class="col-sm-9">
                            <input name="confpass" type="password" class="form-control form-control-success" value="" required>
							
                          </div>
                        </div>												
						<hr>
                        <div class="form-group row">       
                          <div class="col-sm-9 offset-sm-4">
                            <input type="submit" value="บันทึกข้อมูล" class="btn btn-primary">
                          </div>
                        </div>
						
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			



          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>

  </body>
</html>