<!DOCTYPE html>
<html>
  <head>
  <link rel="shortcut icon" href="img/seo.svg">
	<title>เข้าสู่ระบบ | ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	?>
  </head>
  <body>
    <div class="page login-page">
      <div class="container d-flex align-items-center">
        <div class="form-holder has-shadow">
          <div class="row">
            <!-- Logo & Information Panel-->
            <div class="col-lg-6">
              <div class="info d-flex align-items-center">
                <div class="content">
                  <div class="logo">
                    <h1>เว็บฐานข้อมูลงานวิจัย</h1>
                  </div>
                  <p>มหาวิทยาลัยเทคโนโลนีราชมงคลอีสาน วิทยาเขตขอนแก่น</p>
                </div>
              </div>
            </div>
			 
            <!-- Form Panel    -->
            <div class="col-lg-6 bg-white">
              <div class="form d-flex align-items-center">
                <div class="content">
                  <form method="post" class="form-validate" action="action/ac-login.php" method="post">			 
				  
                    <div class="form-group">
                      <input id="username" type="text" name="username" required data-msg="Please enter your username" class="input-material">
                      <label for="username" class="label-material">User Name</label>
                    </div>
                    <div class="form-group">
                      <input id="password" type="password" name="password" required data-msg="Please enter your password" class="input-material">
                      <label for="password" class="label-material">Password</label>
                    </div>
					<input id="login" type="submit" class="btn btn-primary" value="Login" target="">
                    <!-- This should be submit button but I replaced it with <a> for demo purposes-->
                  </form><a href="forgotpass.php" class="forgot-pass">ลืมรหัสผ่าน?</a><br><small> กรณีที่ไม่ใช่สมาชิกท่านสามารถเยี่ยมชมเว็บไซต์ได้ที่นี่ </small><a href="a_guest/a1-index.php" class="signup"> เยี่ยมชม</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="copyrights text-center">
        <p>Design by <a class="external">RMUTI KKC</a>
          <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
        </p>
      </div>
    </div>
	

	
	
	
	
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
  </body>
</html>