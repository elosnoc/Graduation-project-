<!DOCTYPE html>
<?php
include 'ac-checklogin.php';
?>
<html>
  <head>
    <title>ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	include'action/dblink.php';
	$sql2 = "SELECT *
					 FROM faculty";
	$query2= mysqli_query($link, $sql2);
	?>
  </head>
  <body>

  
  
  
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'ad-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">

            <div class="container-fluid">
              <div class="row">                
				<div class="col-lg-7 mx-auto">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">เพิ่มสมาชิก</h3>
                    </div>
                    <div class="card-body">
					
                      
                      <form class="form-horizontal" method="post" action="action/ad-acdivadd.php">
					  
                        <div class="form-group row">
                          <label class="col-sm-2 form-control-label">คณะ</label>
                          <div class="col-sm-9">
                            <select id="fac" name="fac" class="custom-select">
										<option  value="" disabled selected>-- กรุณาเลือก --</option>
										<?php 
										while($objResult2 = mysqli_fetch_array($query2)){
										?>								
										<option value="<?php echo $objResult2["fac_id"]; ?>">   <?php echo $objResult2["mem_fac"];?> </option>																	
										<?php																				
										}
										
										?>								
							</select>						
                          </div>
                        </div>
						
						<div class="form-group row">
                          <label class="col-sm-2 form-control-label">สาขาวิชา</label>
                          <div class="col-sm-9">
                            <input  type="text" name="div" class="form-control form-control-success" required>							
                          </div>
                        </div>				
						
					
						<hr>
                        <div class="form-group row">       
                          <div class="col-sm-9 offset-sm-5">
                            <input type="submit" value="บันทึกข้อมูล" class="btn btn-primary">
                          </div>
                        </div>
						
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			



          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>

  </body>
</html>