<?php
$serverName = "localhost";
	$userName = "root";
	$userPassword = "";
	$dbName = "research";

	$link = mysqli_connect($serverName,$userName,$userPassword,$dbName);
	
	$sql= "	UPDATE division 
			SET 	div_name = '".$_POST["divname"]."'								
					
			WHERE	division.div_id = '".$_POST["divid"]."' ";
			
			$query = mysqli_query($link,$sql); 
		
		echo '<script type="text/javascript">'; 
		echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
		echo 'window.location.href = "ad-div-edit.php";';
		echo '</script>';
		?>