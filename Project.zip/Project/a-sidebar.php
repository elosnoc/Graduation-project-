<?php 
			include'action/dblink.php';
			$sql = "SELECT * 	FROM member								
								WHERE member.username = '".$_SESSION['username']."'	";	
			$query= mysqli_query($link, $sql);
			$objResult = mysqli_fetch_array($query); 			
		?>

<nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            
            <div class="title">
			  <h1 class="h4">ยินดีต้อนรับ</h1>
              <h1 class="h4">คุณ <?php echo " ".$objResult['mem_name']." ".$objResult['mem_surname']." "; ?> </h1>
              <p>สถานะ : สมาชิก</p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">เมนูหลัก</span>
          <ul class="list-unstyled">
                      <li><a href="#research" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-search"></i>ค้นหางานวิจัย </a>
                      <ul id="research" class="collapse list-unstyled ">
                        <li><a href="index.php">ค้นหาจากชื่องานวิจัย</a></li>
						<li><a href="index-namere.php">ค้นหาจากชื่อผู้วิจัย</a></li>
						<li><a href="index-year.php">ค้นหาจากปีที่วิจัย</a></li>
						<li><a href="index-money.php">ค้นหาจากประเภทงบประมาณ</a></li>
						<li><a href="index-type.php">ค้นหาจากประเภทงานวิจัย</a></li>                                              
                      </ul>
                    </li>
					
					<li><a href="#researcher" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-user"></i>ค้นหานักวิจัย </a>
                      <ul id="researcher" class="collapse list-unstyled ">
                        <li><a href="researcher.php">ค้นหาจากชื่อ</a></li>
						<li><a href="researcher-faculty.php">ค้นหาจากชื่อคณะ</a></li>
						<li><a href="researcher-division.php">ค้นหาจากชื่อสาขา</a></li>						                                             
                      </ul>
                    </li> 
					                                      
                    <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-edit"></i>จัดการงานวิจัย </a>
                      <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                        <li><a href="resend.php">ส่งงานวิจัย</a></li>
                        <li><a href="reedit.php">แก้ไขงานวิจัย</a></li>                        
                      </ul>
                    </li>				

          </ul><span class="heading">ข้อมูลส่วนตัว</span>
          <ul class="list-unstyled">
		  <li><a href="#you" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-address-card-o"></i>จัดการข้อมูลส่วนตัว </a>
                      <ul id="you" class="collapse list-unstyled ">
                        <li><a href="memedit.php">แก้ไขข้อมูลส่วนตัว</a></li>
                        <li><a href="chgpass.php">เปลี่ยนรหัสผ่าน</a></li>                        
                      </ul>
                    </li>	
          
            
          </ul>
        </nav>