<?php include 'ac-checklogin.php';?>
<!DOCTYPE html>
<html>
  <head>
    <title>ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	?>
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'a-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">
		    <?php	
   
				$strKeyword = null;
				if(isset($_POST["research"]))
				{
					$strKeyword = $_POST["research"];
				}
			?>
           
			
			<?php
	$serverName = "localhost";
	$userName = "root";
	$userPassword = "1234qwer";
	$dbName = "research";

	$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);
	mysqli_set_charset($conn, "utf8");
	$id = $_GET["id"];
	$sql = "SELECT * FROM attribute WHERE re_id = '".$id."' ";
	
	$objQuery =  mysqli_query($conn, $sql);
	$objResult = mysqli_fetch_array($objQuery); 
	if(!$objResult)
	{
		echo "Not found RE=".$_GET["id"];
	}
	else
	{
	
	?>

			 <div class="container-fluid">
              <div class="row">                
                <div class="col-lg-10 mx-auto">
                  <div class="daily-feeds card">                     
                    <div class="card-header">
                      <h3 class="h4">งานวิจัย</h3>
                    </div>
                    <div class="card-body no-padding">
                      <!-- Item-->
                      <div class="item">
                        <div class="feed d-flex justify-content-between">                       
						  <div class="table-responsive">          
						  
							<table class="table table-striped table-hover">
							  <thead>
								<tr>
								  <th width="15%"></th>
								  <th></th>
								  
								</tr>
							  </thead>
							  
							  
							  <tbody>
								<tr>
								  <th width="10%">ชื่องานวิจัยภาษาไทย</th>
								  <th><?php echo $objResult["re_name_th"];?></th>								  
								</tr>
								
								<tr>
								  <th width="10%">ชื่องานวิจัยภาษาอังกฤษ</th>
								  <th><?php echo $objResult["re_name_eng"];?></th>								  
								</tr>
								
								<tr>
								  <th width="10%">ปีที่วิจัยเสร็จสิ้น</th>
								  <th><?php echo $objResult["re_year"];?></th>								  
								</tr>
								
								<tr>
								  <th width="10%">ประเภทงานวิจัย</th>
								  <th><?php echo $objResult["re_type"];?></th>								  
								</tr>
								
								<tr>
								  <th width="10%">ประเภทงบประมาณ</th>
								  <th><?php echo $objResult["re_money"];?></th>								  
								</tr>
								
								<tr>
								  <th width="10%">บทคัดย่อ</th>
								  <th><a href="#">ดาวน์โหลด</a></th>								  
								</tr>
								
								<tr>
								  <th width="10%"></th>
								  <th>
									<center> 
										<object type="application/pdf" data="uploads/1.pdf" width="100%" height="900" ></object>										
									<center>									
								  </th>								  
								</tr>
						
							  </tbody>					  
							  
							  
							</table>
							
						  </div>
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
	<?php
	}
	?>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
  </body>
</html>