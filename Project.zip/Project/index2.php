<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
     <title>ฐานข้อมูลงานวิจัย| มทร. วิทยาเขตขอนแก่น</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="index/images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="index/images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="index/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="index/style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="index/css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="index/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="index/css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="index/js/modernizer.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="host_version"> 
    <!-- LOADER -->
	<div id="preloader">
		<div class="loader-container">
			<div class="progress-br float shadow">
				<div class="progress__item"></div>
			</div>
		</div>
	</div>
	<!-- END LOADER -->	
	

	
	<div id="carouselExampleControls" class="carousel slide bs-slider box-slider" data-ride="carousel" data-pause="hover" data-interval="false" >
		<!-- Indicators -->

		
		<div class="carousel-inner" role="listbox">
			<div class="carousel-item active">
				<div id="home" class="first-section" style="background-image:url('index/images/slider-01.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-right">
									<div class="big-tagline">
										<h2><strong style="font-size:1.26em;">เว็บฐานข้อมูลงานวิจัย<br></strong></h2>
										<h2>มหาวิทยาลัยเทคโนโลยีราชมงคลอีสานวิทยาเขตขอนแก่น</h2>
										<p class="lead">ยินดีต้อนรับเข้าสู่เว็บไซต์ ท่านสามารถค้นหาข้อมูลงานวิจัยของมหาวิทยาลัยเทคโนโลยีราชมงคลอีสานวิทยาเขตขอนแก่นได้ที่นี่</p>
											<a href="login.php" class="hover-btn-new"><span style="color:white;">เข้าสู่ระบบ</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="a_guest/a1-index.php" class="hover-btn-new"><span style="color:white;">เข้าสู่เว็บไซต์</span></a>
									</div>
								</div>
							</div><!-- end row -->            
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
		</div>
		
	</div>



    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>

    <!-- ALL JS FILES -->
    <script src="index/js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="index/js/custom.js"></script>
	<script src="index/js/timeline.min.js"></script>
	<script>
		timeline(document.querySelectorAll('.timeline'), {
			forceVerticalMode: 700,
			mode: 'horizontal',
			verticalStartPosition: 'left',
			visibleItems: 4
		});
	</script>
</body>
</html>