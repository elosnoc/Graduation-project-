<html>
<head>
<title>DEL</title>
</head>
<body>
<?php
	ini_set('display_errors', 1);
	error_reporting(~0);

	$serverName = "localhost";
	$userName = "root";
	$userPassword = "";
	$dbName = "research";

	$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

	$id = $_GET["id"];
	$sql = "DELETE FROM attribute WHERE re_id = '".$id."' ";

	$query = mysqli_query($conn,$sql);

	if(mysqli_affected_rows($conn)) {
		 echo '<script type="text/javascript">'; 
		echo 'alert("ลบข้อมูลเสร็จสิ้น");'; 
		echo 'window.location.href = "reedit.php";';
		echo '</script>';
	}

	mysqli_close($conn);
?>
</body>
</html>
