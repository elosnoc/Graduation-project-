
<!DOCTYPE html>
<html>
  <head>
    <title>ค้นหางานวิจัย | ฐานข้อมูลงานวิจัย มทร.อีสาน วิทยาเขต ขอนแก่น</title>
    <?php
	include 'a-top.php';
	include 'action/ac-checklogin.php';
	?>
	
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
		<?php include 'a-header.php';?>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <?php include 'a-sidebar.php'; ?>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">ฐานข้อมูลงานวิจัย มหาวิทยาลัยเทคโนโลยีราชมงคลอีสาน วิทยาเขต ขอนแก่น</h2>
            </div>
          </header>
		  
          <br>       
          <!-- Updates Section                                                -->
          <section class="updates no-padding-top">
		
<?php 
			include'action/dblink.php';
			$sql = "SELECT * 	FROM attribute 
								LEFT JOIN member 
								ON attribute.username = '".$_SESSION['username']."'
								WHERE attribute.username = member.username";
										
			$query= mysqli_query($link, $sql);			
?>

			 <div class="container-fluid">
              <div class="row">                
                <div class="col-lg-12 mx-auto">
                  <div class="daily-feeds card">                     
                    <div class="card-header">
                      <h3 class="h4">แก้ไขงานวิจัย</h3>
                    </div>
                    <div class="card-body no-padding">
                      <!-- Item-->
                      <div class="item">
                        <div class="feed d-flex justify-content-between">                       
						  <div class="table-responsive">                       
							<table class="table table-striped table-hover">							  
							  <thead>
								<tr style="text-align:center;">
								  <th scope="col">#</th>
								  <th scope="col">ชื่องานวิจัยภาษาไทย</th>
								  <th scope="col">ผู้วิจัย</th>
								  <th scope="col">ปีที่วิจัย</th>
								  <th scope="col">แก้ไข/ลบ</th>
								</tr>
							  </thead>
							  <tbody>					
								  
									  <?php 								
											$count = 1;
											while($row = mysqli_fetch_array($query)) {
											echo "<tr>";
											echo"<th class\"row\"> $count </th>";
											$count++;
											$id = $row["re_id"];
											echo "<td class=\"php_table\"> {$row["re_name_th"]}</td>";
											echo "<td>".$row["mem_name"]." ".$row["mem_surname"]."</td>";
											echo "<td> {$row["re_year"]}</td>";
											echo "<td> 	
													<a class=\"btn btn-info\" href=\"reedit-form.php?id=$id\">แก้ไขข้อมูล</a>	
													<a href=\"del.php?id=$id\" class=\"btn btn-danger\" href=\"research.php\" onclick=\"return confirm('กรุณายืนยันการลบอีกครั้ง !!!')\">ลบข้อมูล</a>																
												</td>";
										
											echo"</tr>";
										}							
										?>		
							  </tbody>
							</table>
						  </div>
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		  
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>RMUTI KKC &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a class="external">RMUTI KKC</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
  </body>
</html>