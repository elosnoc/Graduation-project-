<?php
include 'ac-checklogin.php';
$link = mysqli_connect('localhost', 'root', '', 'research') or die(mysqli_connect_error());
mysqli_set_charset($link, "utf8");				

if (($_FILES['my_file']['name']!="" && $_FILES["my_file"]["type"] == "application/pdf"))
{
// Where the file is going to be stored
	$target_dir = "uploads/";
	$file = $_FILES['my_file']['name'];
	$path = pathinfo($file);
	$filename = $path['filename'];
	$ext = $path['extension'];
	$temp_name = $_FILES['my_file']['tmp_name'];
	$path_filename_ext = $target_dir.$filename.".".$ext;
 
// Check if file already exists
 move_uploaded_file($temp_name,$path_filename_ext);
 

	mysqli_set_charset($link, "utf8");
	$sql= "	UPDATE attribute 
			SET 	re_name_th = '".$_POST["name-th"]."',
					re_name_eng ='".$_POST["name-eng"]."',
					re_year ='".$_POST["year"]."',
					re_type ='".$_POST["re-type"]."',
					re_money ='".$_POST["money"]."',			
					re_abs ='$path_filename_ext' 					
			WHERE	attribute.re_id = '".$_SESSION["re_id"]."' ";
			
			$query = mysqli_query($link,$sql); 

		echo '<script type="text/javascript">'; 
		echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
		echo 'window.location.href = "reedit.php";';
		echo '</script>';		
 
}

else if (($_FILES['my_file']['name']=="" ))
{

	$sql= "	UPDATE attribute 
			SET 	re_name_th = '".$_POST["name-th"]."',
					re_name_eng ='".$_POST["name-eng"]."',
					re_year ='".$_POST["year"]."',
					re_type ='".$_POST["re-type"]."',
					re_money ='".$_POST["money"]."'					
					
			WHERE	attribute.re_id = '".$_SESSION["re_id"]."' ";
			
			$query = mysqli_query($link,$sql); 

		echo '<script type="text/javascript">'; 
		echo 'alert("บันทึกข้อมูลเสร็จสิ้น");'; 
		echo 'window.location.href = "reedit.php";';
		echo '</script>';
}

else
{
	
	echo '<script type="text/javascript">'; 
	echo 'alert("กรุณาเลือกไฟล์  PDF เท่านั้น !!!");'; 
	echo 'window.location.href = "reedit.php";';
	echo '</script>';
}

session_unregister($_SESSION['re_id']);
	
?>